package com.example.eboneadminpanel.core

/**
 * Ebone Super Admin - Firestore ke tamam Paths ek jagah
 */
object FirestorePaths {

    // ---------- Top-level Collections ----------
    const val COMPANIES = "companies"
    const val COUNTERS = "counters"
    const val SUPER_ADMIN = "superAdmin"

    // ---------- Sub-collections (Company ke andar) ----------
    const val ADMINS = "admins"
    const val MANAGERS = "managers"
    const val SUPERVISORS = "supervisors"
    const val EMPLOYEES = "employees"
    const val COMPLAINTS = "complaints"

    // ---------- Document Names ----------
    const val SETTINGS_DOC = "settings"
    const val COMPANY_INFO_DOC = "companyInfo"
    const val LICENSE_DOC = "license"

    // ---------- Field Names (Company Document ke andar) ----------
    const val FIELD_COMPANY_NAME = "companyName"
    const val FIELD_CITY = "city"
    const val FIELD_OWNER_NAME = "ownerName"
    const val FIELD_LICENSE_STATUS = "licenseStatus"
    const val FIELD_LICENSE_EXPIRY = "licenseExpiry"
    const val FIELD_CREATED_AT = "createdAt"

    // ---------- Field Names (Counter Document ke andar) ----------
    const val FIELD_LAST_NUMBER = "lastNumber"

    // ---------- Field Names (Super Admin Document ke andar) ----------
    const val FIELD_ACCESS_LEVEL = "accessLevel"
}