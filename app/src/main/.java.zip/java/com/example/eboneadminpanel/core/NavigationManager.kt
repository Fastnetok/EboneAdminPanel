package com.example.eboneadminpanel.core

import android.app.Activity
import android.content.Intent
import com.example.eboneadminpanel.AdminDashboardActivity
import com.example.eboneadminpanel.superadmin.dashboard.SuperDashboardActivity

/**
 * NavigationManager
 * Login ke baad Role ke mutabiq sahi Dashboard par le jata hai.
 */
object NavigationManager {

    fun goToCorrectDashboard(activity: Activity, sessionManager: SessionManager) {
        val intent = if (sessionManager.isSuperAdmin()) {
            Intent(activity, SuperDashboardActivity::class.java)
        } else {
            Intent(activity, AdminDashboardActivity::class.java)
        }
        activity.startActivity(intent)
        activity.finish()
    }
}