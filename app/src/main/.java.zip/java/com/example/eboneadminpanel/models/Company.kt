package com.example.eboneadminpanel.models

/**
 * Company Data Model
 * Firestore "companies" collection ke ek document ko represent karta hai.
 */
data class Company(
    var companyId: String = "",          // e.g. LHR-0049 (Document ID bhi yahi hoga)
    var companyName: String = "",
    var city: String = "",
    var ownerName: String = "",
    var licenseStatus: String = "active", // active / expired / suspended
    var licenseExpiry: Long = 0L,         // timestamp
    var createdAt: Long = 0L,             // timestamp
    var totalEmployees: Int = 0,
    var totalComplaints: Int = 0,
    var pendingComplaints: Int = 0,
    var resolvedComplaints: Int = 0
) {
    // Firestore ko empty constructor chahiye hota hai deserialize karne ke liye
    constructor() : this("", "", "", "", "active", 0L, 0L, 0, 0, 0, 0)
}