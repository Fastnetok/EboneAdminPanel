package com.example.eboneadminpanel.superadmin.companymanager

class CompanyManagerActivity {
}