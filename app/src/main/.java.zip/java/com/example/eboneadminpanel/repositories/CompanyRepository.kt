package com.example.eboneadminpanel.repositories

import com.example.eboneadminpanel.core.FirestorePaths
import com.example.eboneadminpanel.models.Company
import com.google.firebase.firestore.FirebaseFirestore

/**
 * CompanyRepository
 * Firestore ke "companies" collection ke saath tamam kaam
 * (Add, Get All, Update, Delete) yahan hote hain.
 */
class CompanyRepository {

    private val db = FirebaseFirestore.getInstance()
    private val companiesRef = db.collection(FirestorePaths.COMPANIES)

    interface CompanyListCallback {
        fun onSuccess(companies: List<Company>)
        fun onError(message: String)
    }

    interface SimpleCallback {
        fun onSuccess()
        fun onError(message: String)
    }

    /** Nayi Company Firestore mein add karta hai */
    fun addCompany(company: Company, callback: SimpleCallback) {
        companiesRef.document(company.companyId)
            .set(company)
            .addOnSuccessListener { callback.onSuccess() }
            .addOnFailureListener { e -> callback.onError(e.message ?: "Company add nahi ho saki") }
    }

    /** Tamam Companies ki list laata hai */
    fun getAllCompanies(callback: CompanyListCallback) {
        companiesRef.get()
            .addOnSuccessListener { snapshot ->
                val companies = snapshot.documents.mapNotNull { it.toObject(Company::class.java) }
                callback.onSuccess(companies)
            }
            .addOnFailureListener { e -> callback.onError(e.message ?: "Companies load nahi hui") }
    }

    /** Company ki maujooda maloomat update karta hai */
    fun updateCompany(company: Company, callback: SimpleCallback) {
        companiesRef.document(company.companyId)
            .set(company)
            .addOnSuccessListener { callback.onSuccess() }
            .addOnFailureListener { e -> callback.onError(e.message ?: "Company update nahi ho saki") }
    }

    /** Company delete karta hai */
    fun deleteCompany(companyId: String, callback: SimpleCallback) {
        companiesRef.document(companyId)
            .delete()
            .addOnSuccessListener { callback.onSuccess() }
            .addOnFailureListener { e -> callback.onError(e.message ?: "Company delete nahi ho saki") }
    }
}