package com.example.eboneadminpanel.superadmin.companymanager

class EditCompanyDialog {
}