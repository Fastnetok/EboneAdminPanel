package com.example.eboneadminpanel

data class Complaint(

    var complaintId: String = "",

    var userId: String = "",

    var address: String = "",

    var phoneNumber: String = "",

    var details: String = "",

    var status: String = "Pending",

    var assignedTo: String = "",

    var assignedTime: Long = 0,

    var resolvedBy: String = "",

    var resolvedTime: Long = 0,

    var displayOrder: Long = 0,

    var createdTime: Long = System.currentTimeMillis()

)