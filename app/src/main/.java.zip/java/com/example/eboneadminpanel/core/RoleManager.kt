package com.example.eboneadminpanel.core

import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

/**
 * RoleManager
 * Login karne wale user ka Role check karta hai:
 * Super Admin hai ya Company Admin.
 */
object RoleManager {

    private val auth = FirebaseAuth.getInstance()
    private val db = FirebaseFirestore.getInstance()

    interface RoleCheckCallback {
        fun onRoleFound(role: String, companyId: String?)
        fun onError(message: String)
    }

    /**
     * Current logged-in user ka role check karta hai.
     * Pehle superAdmin collection check karta hai,
     * agar wahan na mile to company_admin maan liya jata hai.
     */
    fun checkCurrentUserRole(callback: RoleCheckCallback) {
        val uid = auth.currentUser?.uid
        if (uid == null) {
            callback.onError("User logged in nahi hai")
            return
        }

        db.collection(FirestorePaths.SUPER_ADMIN)
            .document(uid)
            .get()
            .addOnSuccessListener { document ->
                if (document != null && document.exists()) {
                    // Yeh Super Admin hai
                    callback.onRoleFound(Constants.ROLE_SUPER_ADMIN, null)
                } else {
                    // Super Admin nahi mila, is liye Company Admin maana jayega
                    findCompanyForAdmin(uid, callback)
                }
            }
            .addOnFailureListener { e ->
                callback.onError(e.message ?: "Role check karte waqt error aaya")
            }
    }

    /**
     * Agar Super Admin nahi hai, to yeh function pata karta hai
     * ke yeh User kis Company ka Admin hai.
     * (Abhi ke liye simple placeholder - baad mein companies collection group query se update hoga)
     */
    private fun findCompanyForAdmin(uid: String, callback: RoleCheckCallback) {
        // NOTE: Yeh function Phase 2 mein poora likha jayega jab
        // Company Admin ka data structure Firestore mein ban jayega.
        callback.onRoleFound(Constants.ROLE_COMPANY_ADMIN, null)
    }
}