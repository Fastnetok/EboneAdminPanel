package com.example.eboneadminpanel.superadmin.dashboard

/**
 * DashboardStats
 * Super Admin Dashboard par nazar aane wale numbers.
 */
data class DashboardStats(
    var totalCompanies: Int = 0,
    var totalEmployees: Int = 0,
    var totalComplaints: Int = 0,
    var pendingComplaints: Int = 0,
    var resolvedComplaints: Int = 0,
    var inProgressComplaints: Int = 0
)